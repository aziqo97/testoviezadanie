<div>
    <div>User: {{ $application->user->name }}</div>
    <div>Id: {{ $application->id }}</div>
    <div>Subject: {{ $application->subject }}</div>
    <div>Message: {{ $application->message }}</div>
    <div>Time: {{ $application->created_at }}</div>
</div>
