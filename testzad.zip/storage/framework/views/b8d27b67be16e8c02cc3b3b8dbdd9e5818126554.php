<div>
    <div>User: <?php echo e($application->user->name); ?></div>
    <div>Id: <?php echo e($application->id); ?></div>
    <div>Subject: <?php echo e($application->subject); ?></div>
    <div>Message: <?php echo e($application->message); ?></div>
    <div>Time: <?php echo e($application->created_at); ?></div>
</div>
<?php /**PATH W:\domains\testzad\testzad\resources\views/emails/application-created.blade.php ENDPATH**/ ?>